# Web Development Activity-Based Learning — Project Report

## 1. Introduction
This project demonstrates three practical website interfaces using HTML, CSS, and JavaScript. The pages use responsive layouts so that they remain usable on laptop, tablet, and mobile screens.

## 2. Objectives
- Apply semantic HTML to organize page content.
- Use CSS for layout, typography, color, cards, and responsive design.
- Add small JavaScript interactions to improve usability.
- Practice creating different website types from case-study requirements.

## 3. Case Study 1 — Personal Portfolio
The portfolio introduces a student profile and provides sections for education, technical skills, projects, hobbies, achievements, and contact. A responsive navigation bar and subtle CSS effects improve navigation and presentation.

## 4. Case Study 2 — Online Learning Platform
The learning page presents course categories, searchable course cards, instructor details, course descriptions, learning objectives, progress indicators, and enrollment buttons. Enrollment buttons show a front-end demo message only.

## 5. Case Study 3 — Student Academic Dashboard
The dashboard uses a sidebar, student profile card, subject table, attendance progress bars, sample semester scores, examination schedule, and announcements. All academic values are sample data and must be replaced with actual data if required.

## 6. Tools and Technologies
- HTML5
- CSS3 (Flexbox, Grid, media queries, transitions)
- JavaScript (DOM events and basic interactions)
- Web browser (for testing)

## 7. Testing
- Open each `index.html` file in a modern browser.
- Check that the navigation links scroll to the correct sections.
- Try the course search and category filter.
- Click enrollment and contact buttons to see demo messages.
- Resize the browser window to check responsive behavior.
- Check the dashboard cards and sample tables for readable layout.

## 8. Limitations
This is a front-end academic demonstration. It does not include a database, server, real login, live course enrollment, or verified academic records.

## 9. Conclusion
The project provides hands-on practice in responsive web design and simple interactivity across three different case studies.
