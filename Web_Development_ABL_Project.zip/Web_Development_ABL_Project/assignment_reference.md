# Assignment Reference

The uploaded **Web Development Activity-Based Learning: Instructions** sheet asks students to select any **3 case studies** and design and develop the webpages. This project implements these three listed case studies:

1. **Personal Portfolio Website**: profile, educational qualifications, technical skills, hobbies, projects, achievements, resume, contact information, CSS animations, responsive layouts, and interactive navigation effects.
2. **Online Learning Platform Interface**: course categories, lesson thumbnails/cards, instructor profiles, course descriptions, learning objectives, enrollment buttons, responsive course cards, and progress indicators.
3. **Student Academic Dashboard**: student details, semester results, attendance percentages, subject information, examination schedules, announcements, tables, progress bars, cards, and sidebar layout.

The sheet states that evaluation is worth 10 marks and is awarded by the respective Web Development faculty member as per the regular academic schedule. Please follow any additional instructions given by your faculty.
