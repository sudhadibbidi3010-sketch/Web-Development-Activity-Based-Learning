# Web Development Activity-Based Learning Project

**Student:** Dibbidi Naga Venkata Jaya Sudha  
**Course:** B.Tech CSE-AIML — First Year  
**Project:** Web Development Activity-Based Learning (select any 3 case studies)

## Case studies included
1. **Personal Portfolio Website** — profile, education, skills, hobbies, projects, achievements, resume/contact sections, responsive navigation and CSS effects.
2. **Online Learning Platform** — course categories, course cards, instructor information, learning objectives, progress indicators and interactive enrollment buttons.
3. **Student Academic Dashboard** — student details, subject list, attendance bars, sample semester results, examination schedule and announcements.

## Technologies
- HTML5 for structure
- CSS3 for styling, responsive layouts, grids, cards, and transitions
- Vanilla JavaScript for navigation, filters, button interactions, and demo messages

## How to run
1. Extract the ZIP file.
2. Open the `index.html` inside any one case-study folder in a browser.
3. No installation or internet connection is required for the core pages.

## Folder structure
- `01_personal_portfolio/` — portfolio website files
- `02_online_learning_platform/` — learning platform files
- `03_student_academic_dashboard/` — academic dashboard files
- `project_report.md` — overview, objectives, design and testing notes
- `assignment_reference.md` — brief drawn from the supplied assignment sheet

## Important notes
- Names, marks, attendance, dates, course progress, and course descriptions shown in the demo are sample content for demonstration. Update them to your actual details before submitting.
- The enrollment and contact interactions are front-end demonstrations; no data is sent to a server.
